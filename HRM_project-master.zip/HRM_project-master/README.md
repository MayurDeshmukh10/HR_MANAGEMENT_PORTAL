# HRM_project
This is a HR (Human Resource) management portal. 
It helps a company to keep track of its employees, their attendance, details of each employee, their salary
and records of salary payments and increments, joining date of the employees, events of the company, a centralized 
notice board and so on.

To run the project, please follow the following steps --

1. Download the files and open the index.html file.
2. Enter your name and a password for logging in.
3. Navigate and explore the front-end of the HRM portal.

The back-end has still not been added.
